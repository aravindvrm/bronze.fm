---
name: Bronze FM
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#20201f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d8c2b2'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#a18d7f'
  outline-variant: '#534438'
  surface-tint: '#ffb779'
  primary: '#ffb779'
  on-primary: '#4c2700'
  primary-container: '#cd7f32'
  on-primary-container: '#432200'
  inverse-primary: '#8e4e00'
  secondary: '#ffb596'
  on-secondary: '#581e00'
  secondary-container: '#76320f'
  on-secondary-container: '#fd9d71'
  tertiary: '#60d6f1'
  on-tertiary: '#003640'
  tertiary-container: '#009fb9'
  on-tertiary-container: '#002f38'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcc1'
  primary-fixed-dim: '#ffb779'
  on-primary-fixed: '#2e1500'
  on-primary-fixed-variant: '#6c3a00'
  secondary-fixed: '#ffdbcd'
  secondary-fixed-dim: '#ffb596'
  on-secondary-fixed: '#360f00'
  on-secondary-fixed-variant: '#76320f'
  tertiary-fixed: '#abedff'
  tertiary-fixed-dim: '#60d6f1'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 80px
    fontWeight: '700'
    lineHeight: 88px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The design system is built on a "Neo-Radio" aesthetic—a fusion of classical broadcast elegance and modern digital precision. It targets a sophisticated audience that values high-fidelity audio and curated editorial content. 

The visual language draws heavily from **Minimalism** and **High-Contrast Typography**, utilizing generous whitespace to allow content to breathe. The emotional response should be one of "quiet luxury"—premium, rhythmic, and authoritative. Every interaction should feel intentional, mirroring the deliberate nature of a masterfully produced radio segment.

## Colors

The palette is centered around a dark, immersive experience. **Bronze (#CD7F32)** serves as the primary accent, used sparingly for interactive elements and brand markers to signify high value. **Sienna (#A0522D)** provides depth as a secondary tone for hovered states or supporting graphics.

The foundation is **Deep Charcoal (#1A1A1A)**, providing a high-contrast backdrop for **Warm Off-White (#FDF5E6)** typography. This off-white reduces the harshness typically found in pure white-on-black UI, enhancing readability for long-form editorial content.

## Typography

Typography is the core of this design system. We use **Bodoni Moda** for all editorial and display moments to evoke a sense of heritage and high-fashion broadcasting. Large display sizes use negative letter spacing to create a tight, rhythmic feel.

**Hanken Grotesk** handles all functional duties. It is chosen for its contemporary geometric clarity, providing a sharp counterpoint to the serif headlines. Labels should frequently use uppercase styling with increased letter spacing to maintain an organized, catalog-like appearance typical of professional audio workstations.

## Layout & Spacing

This design system employs a **Fixed Grid** philosophy for desktop (12 columns) and a **Fluid Grid** for mobile (4 columns). The spacing rhythm is generous, emphasizing the "Premium" mood through "Empty Space as Luxury."

Horizontal margins are intentionally wide (64px on desktop) to center the user's focus on the content. Vertical stacks use a 8px base unit, but primary sections should be separated by `stack-lg` (48px) to maintain the distinct, editorial flow of the brand.

## Elevation & Depth

To maintain a sophisticated and modern feel, the design system avoids heavy shadows. Depth is created through **Tonal Layering** and **High-Contrast Outlines**.

1.  **Level 0 (Background):** The deepest layer (#1A1A1A).
2.  **Level 1 (Surface):** Container elements (#242424) used for cards and navigation bars.
3.  **Accents:** Subtle, low-opacity Bronze borders (1px) are used to define interactive areas instead of shadows.
4.  **Glassmorphism:** For the "Now Playing" bar and overlays, a subtle backdrop blur (20px) with a 10% white tint is used to create a sense of presence without breaking the dark aesthetic.

## Shapes

The shape language is "Soft-Technical." Elements use a small 4px (0.25rem) corner radius to feel precise and professional—reminiscent of high-end audio hardware. 

- Use **Sharp (0px)** for primary layout containers and hero images to maintain an architectural, editorial look.
- Use **Soft (4px)** for functional components like buttons, input fields, and album art thumbnails.
- **Pill-shapes** are reserved exclusively for "Live" indicators and active category tags to make them distinct from structural elements.

## Components

### Buttons
Primary buttons use the Bronze (#CD7F32) fill with Deep Charcoal text. They are rectangular with a 4px radius. Secondary buttons use a transparent background with a 1px Bronze border and Bronze text.

### Audio Cards
Cards use the Surface (#242424) color. They feature large-scale album art with "Bodoni Moda" titles. Hover states should trigger a slight scale-up of the image and a bronze tint on the title text.

### Inputs
Search and form fields utilize a "ghost" style: a 1px border of #FDF5E6 at 20% opacity. Upon focus, the border transitions to solid Bronze.

### Now Playing Bar
A persistent footer component. It uses a frosted glass effect (backdrop-blur) to sit above the main content. The progress bar for the track is a hairline 2px height, using Bronze for the "played" state and #FDF5E6 at 10% for the "remaining" state.

### Typography-only Lists
For tracklists or archives, remove all borders. Use "Hanken Grotesk" for numbers and "Bodoni Moda" for track titles, creating a "Sheet Music" editorial aesthetic.